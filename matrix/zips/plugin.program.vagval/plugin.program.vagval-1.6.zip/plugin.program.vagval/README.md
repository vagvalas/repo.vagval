# First try for Kodi Wizard


## What it does
-Added a fanart and an icon pack!
Made it to download the build.
Delete the /addon and /userdata folder.
Replace everything with new folders and files.
KILLS Kodi for remaining the skin settings (that was the tricky part)

## THINGS TO DO 
Possible make another build for 20.x
MAYBE back-ported to Python2 for Kodi <19 compatibility